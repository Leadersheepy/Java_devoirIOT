package sakila.spring.services;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Slf4j
class ActorServiceImplTest {

    @Autowired
    ActorService service;
    @Test
    void read() {
    }

    @Test
    void readAll() {
    }

    @Test
    void findByStr() {
        String str = "jo" ;
        var actors = service.findByStr(str);
        log.trace("Nombre d'acteurs trouvés pour l'expression ({}) dans le nom ou prénom: {}",str,actors.size());
        actors.forEach(a->log.trace("{}",a));
    }
}