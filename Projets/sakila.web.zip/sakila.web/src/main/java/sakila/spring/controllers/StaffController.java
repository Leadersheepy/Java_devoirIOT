package sakila.spring.controllers;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import sakila.spring.entities.Staff;
import sakila.spring.services.StaffService;

import java.util.ArrayList;
import java.util.List;

@RestController
@AllArgsConstructor
@Slf4j
@RequestMapping("/staff")
public class StaffController {

    private StaffService service;

    @GetMapping(value = "/picture/{id}", produces = {MediaType.IMAGE_JPEG_VALUE})
    public byte[] getPicture(@PathVariable Long id){
        log.trace("get picture for id :{}",id);
        return service.read(id).getPicture();
    }

    @GetMapping(value = "/pictures", produces = {MediaType.IMAGE_JPEG_VALUE})
    public List<byte[]> getAllPicture(){
        log.trace("getAllPicture");
        ArrayList<byte[]> images = new ArrayList<>();
        var staffs = service.readAll();
        for(Staff s : staffs){
            if ( s.getPicture() != null)
                images.add(s.getPicture());
        }
        return images;
    }

    @PostMapping("/create")
    public Staff create(@RequestBody Staff staff){
        log.trace("Create Staff :{}",staff);
        return service.create(staff);
    }

    @PutMapping("/modify_picture/{id}")
    public Staff modifyPicture(@PathVariable Long id, @RequestBody byte[] picture){
        log.trace("Add Picture to Staff id:{}",id);
        var staff = service.read(id);
        if ( staff == null  )
            return null;
        else {
            staff.setPicture(picture);
            return service.update(staff);
        }
    }
}
