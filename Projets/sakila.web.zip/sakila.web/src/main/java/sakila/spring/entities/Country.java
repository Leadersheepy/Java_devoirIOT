package sakila.spring.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Entity
    @Table(name = "country")
@Setter @Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Country {
    @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
            @Column(name = "country_id", nullable = false)
    private Long id;
    private String country;

    @ToString.Exclude
    @OneToMany(mappedBy = "country")
    private List<City> cities ;

    @Column(name = "last_update")
    private LocalDateTime lastUpdate;

}
