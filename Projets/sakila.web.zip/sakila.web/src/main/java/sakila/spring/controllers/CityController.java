package sakila.spring.controllers;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sakila.spring.entities.City;
import sakila.spring.services.CityService;

import java.util.List;

@RestController
@RequestMapping("/cities")
@Slf4j
@AllArgsConstructor
public class CityController {

    private CityService service;
    @GetMapping("/all")
    public List<City> getAll(){
        return service.readAll();
    }
    @GetMapping("/{id}")
    public City getOne(@PathVariable Long id){
        return service.read(id);
    }
}
