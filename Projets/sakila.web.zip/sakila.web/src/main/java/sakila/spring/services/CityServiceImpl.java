package sakila.spring.services;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import sakila.spring.entities.City;
import sakila.spring.repositories.CityRepository;

import java.util.List;

@Service
    @Slf4j
@AllArgsConstructor
public class CityServiceImpl implements CityService{
    private CityRepository repository;


    @Override
    public City create(City entity) {
        return repository.save(entity);
    }

    @Override
    public City read(Long id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public City update(City entity) {
        return repository.save(entity);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public List<City> readAll() {
        return repository.findAll();
    }
}
