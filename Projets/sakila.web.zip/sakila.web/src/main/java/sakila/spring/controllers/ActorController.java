package sakila.spring.controllers;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sakila.spring.entities.Actor;
import sakila.spring.services.ActorService;

import java.util.List;

@RestController
    @RequestMapping("/actors")
@Slf4j
@AllArgsConstructor
public class ActorController {
    private ActorService service;

    @GetMapping({"/","/all"})
    public List<Actor> getAll(){
        return service.readAll();
    }
    @GetMapping("/search/{str}")
    public List<Actor> serachFor(@PathVariable String str){
        return service.findByStr(str);
    }

    @GetMapping("/{id}")
    public Actor getAllFilms(@PathVariable Long id){
        return service.read(id);
    }
}
