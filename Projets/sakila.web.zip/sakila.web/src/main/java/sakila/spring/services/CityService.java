package sakila.spring.services;

import sakila.spring.entities.City;

public interface CityService extends StandardService<City,Long>{
}
