package sakila.spring.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "film")
@Setter @Getter
@NoArgsConstructor @AllArgsConstructor
@ToString
public class Film {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "film_id", nullable = false)
        private Long id;
        private String title;
        private String description;
        @Column(name = "release_year")
        private Integer releaseYear;

        @ManyToMany
        @JoinTable( name = "film_actor",
                joinColumns = @JoinColumn( name = "film_id" ),
                        inverseJoinColumns = @JoinColumn( name = "actor_id" ) )
        @JsonIgnoreProperties(value = "films")
        private List<Actor> actors;

        @Column(name = "last_update")
        private LocalDateTime lastUpdate;

}
