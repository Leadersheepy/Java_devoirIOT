package sakila.spring.services;

import sakila.spring.entities.Actor;
import sakila.spring.entities.Film;

import java.util.List;

public interface ActorService extends StandardService<Actor,Long> {
    List<Actor> findByStr(String str);
}
