package sakila.spring.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import sakila.spring.entities.Actor;

import java.util.List;

public interface ActorRepository extends JpaRepository<Actor,Long> {
    List<Actor> findActorByFirstNameContainingIgnoreCaseOrLastNameContainingIgnoreCase(String str1,String str2);
}
