package sakila.spring.services;

import sakila.spring.entities.Film;

import java.util.List;

public interface FilmService extends StandardService<Film,Long>{
    List<Film> titleLike(String title) ;
}
