package sakila.spring.controllers;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sakila.spring.entities.Film;
import sakila.spring.services.FilmService;

import java.util.List;

@RestController
    @RequestMapping("/films")
        @AllArgsConstructor
public class FilmController {
    private FilmService service;

    @GetMapping("/{id}")
    public Film getOne(@PathVariable Long id){
        return service.read(id);
    }

    @GetMapping("/all")
    public List<Film> getAll(){
        return service.readAll();
    }

    @GetMapping("/title/{title}")
    public List<Film> getAllForTitle(@PathVariable String title){
        return service.titleLike(title);
    }

}
