package sakila.spring.entities;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
    @Table(name = "city")
@NoArgsConstructor @AllArgsConstructor
@ToString(onlyExplicitlyIncluded = false)
@Getter @Setter
public class City {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "city_id", nullable = false)
    private Long id;
    private String city;
    @ManyToOne
        @JoinColumn(name = "country_id")
            @JsonIgnoreProperties(value = "cities")
    private Country country;
    @Column(name = "last_update")
    private LocalDateTime lastUpdate;

}
