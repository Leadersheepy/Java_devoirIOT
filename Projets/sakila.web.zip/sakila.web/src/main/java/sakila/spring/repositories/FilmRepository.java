package sakila.spring.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import sakila.spring.entities.Film;

import java.util.List;

public interface FilmRepository extends JpaRepository<Film,Long> {
    List<Film> findAllByTitleContainingIgnoreCase(String expr);
}
