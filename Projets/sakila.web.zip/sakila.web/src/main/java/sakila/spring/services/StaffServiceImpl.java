package sakila.spring.services;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import sakila.spring.entities.Staff;
import sakila.spring.repositories.StaffRepository;

import java.util.List;

/**
 * Classe implementation des CRUD service
 */
@AllArgsConstructor
@Service
public class StaffServiceImpl implements StaffService{

    private StaffRepository staffRepository;

    @Override
    public Staff create(Staff staff) {
        return staffRepository.save(staff);
    }

    @Override
    public Staff read(Long id) {
        return staffRepository.findById(id).orElse(null);
    }

    @Override
    public Staff update(Staff staff) {
        return staffRepository.save(staff);
    }

    @Override
    public void delete(Long id) {

    }

    @Override
    public List<Staff> readAll() {
        return staffRepository.findAll();
    }
}
