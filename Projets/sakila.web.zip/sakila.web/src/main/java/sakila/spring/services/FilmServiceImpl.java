package sakila.spring.services;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import sakila.spring.entities.Film;
import sakila.spring.repositories.FilmRepository;

import java.util.List;

@Service
    @Slf4j
        @AllArgsConstructor
public class FilmServiceImpl implements FilmService{
    private FilmRepository repository;

    @Override
    public Film create(Film entity) {
        return null;
    }

    @Override
    public Film read(Long id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public Film update(Film entity) {
        return null;
    }

    @Override
    public void delete(Long id) {

    }

    @Override
    public List<Film> readAll() {
        return repository.findAll();
    }

    @Override
    public List<Film> titleLike(String title) {
        return repository.findAllByTitleContainingIgnoreCase(title);
    }
}
