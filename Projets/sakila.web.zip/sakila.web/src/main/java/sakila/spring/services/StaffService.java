package sakila.spring.services;

import sakila.spring.entities.Staff;

/**
 * C reate
 * R ead
 * U pdate
 * D elete
 */
public interface StaffService extends StandardService<Staff,Long>{
}
