package sakila.spring.services;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import sakila.spring.entities.Actor;
import sakila.spring.entities.Film;
import sakila.spring.repositories.ActorRepository;

import java.util.List;

@Service
@AllArgsConstructor
public class ActorServiceImpl implements ActorService{
    private ActorRepository repository;

    @Override
    public Actor create(Actor entity) {
        return null;
    }

    @Override
    public Actor read(Long id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public Actor update(Actor entity) {
        return null;
    }

    @Override
    public void delete(Long id) {
    }

    @Override
    public List<Actor> readAll() {
        return repository.findAll();
    }

    @Override
    public List<Actor> findByStr(String str) {
        return repository.findActorByFirstNameContainingIgnoreCaseOrLastNameContainingIgnoreCase(str,str);
    }

}
