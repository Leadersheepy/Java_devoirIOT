package sakila.spring.entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
    @Table(name = "staff")
        @Setter @Getter
@NoArgsConstructor
@ToString
public class Staff {
    @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
            @Column(name = "staff_id", nullable = false)
    private Long id;
    @Column(name = "first_name", nullable = false)
    private String firstName ;
    @Column(name = "last_name", nullable = false)
    private String lastName ;
    private String email ;

    @Column(name = "store_id", nullable = false)
    private Long storeId;

    @Column(name = "address_id", nullable = false)
    private Long addressId;

    private String username;

    @ToString.Exclude
    private byte[] picture ;

}
